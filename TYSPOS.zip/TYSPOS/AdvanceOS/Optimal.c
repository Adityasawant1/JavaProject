#include<stdio.h>
#define MAX 100
int frames[MAX],ref[MAX],mem[MAX][MAX],faults,sp,n,m,count[MAX];

void accept()
{
        int i;
	printf("Enter no.of frames:");
	scanf("%d", &n);
	printf("Enter no.of references:");
	scanf("%d", &m);
	printf("Enter reference string:\n");
	for(i=0;i<m;i++)
	{
		printf("[%d]=",i);
		scanf("%d",&ref[i]);
	}
}

void disp()
{
  int i,j;
  for(i=0;i<m;i++)
  {
      printf("%d",ref[i]);
  }
  printf("\n");
  for(i=0;i<n;i++)
  {
      for(j=0;j<m;j++)
      {
          if(mem[i][j])
          {
            printf("%3d",mem[i][j]);
          }else
          {
            printf("    ");
          }
      }
      printf("\n");
  }
  printf("Total no of page faults :%d ",faults);
}
int search(int pno)
{
	int i;
	for(i=0;i<n;i++)
	{
		if(frames[i]==pno)
			return i;
	}
	return -1;
}
int get_optimal(int sp,int current_time)
{
    int i,j,farthest = -1,replace_index=-1;
    
    for(i=0;i<n;i++)
    {
        int flag=0;
        
        for(j=current_time+1;j<m;j++)
        {
            if(frames[i]==ref[i])
            {
                flag=1;
                break;
              }
        }
        
        if(!flag)
        {
          return i;
        }
        
        if(farthest<j)
        {
          farthest=j;
          replace_index=i;
        }
      }
      
      return replace_index;
}
void optimal()
{
    int i,j,k;
    
    for(i=0;i<m;i++)
    {
        k=search(ref[i]);
        if(k==-1)
        {
          k=get_optimal(sp,i);
          frames[k]=ref[i];
          faults++;
          
          for(j=0;j<n;j++)
          {
            mem[j][i]=frames[j];
          }
        }
      }
}
int main()
{
  accept();
  optimal();
  disp();
  return 0;
}

