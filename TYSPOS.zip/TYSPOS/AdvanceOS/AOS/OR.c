#include<stdio.h>
#define MAX 20
int frames[MAX], ref[MAX], mem[MAX][MAX], faults, sp, n, m, count[MAX];

// Accepts input for the number of frames, reference string, etc.
void accept() {
    int i;
    printf("Enter no.of frames: ");
    scanf("%d", &n);
    printf("Enter no.of references: ");
    scanf("%d", &m);
    printf("Enter reference string:\n");
    for (i = 0; i < m; i++) {
        printf("[%d] = ", i);
        scanf("%d", &ref[i]);
    }
}

// Displays the reference string, memory state, and total page faults
void disp() {
    int i, j;
    for (i = 0; i < m; i++) {
        printf("%3d", ref[i]);
    }
    printf("\n\n");
    for (i = 0; i < n; i++) {
        for (j = 0; j < m; j++) {
            if (mem[i][j]) 
                printf("%3d", mem[i][j]);
            else 
                printf("   ");
        }
        printf("\n");
    }
    printf("Total Page Faults: %d\n", faults);
}

// Search function to check if the page is already in the frames
int search(int pno) {
    int i;
    for (i = 0; i < n; i++) {
        if (frames[i] == pno)
            return i;
    }
    return -1;
}


int get_optimal(int sp, int current_time) {
    int i, j, farthest = -1, replace_index = -1;
    for (i = 0; i < n; i++) {
        int flag = 0;
        for (j = current_time + 1; j < m; j++) {
            if (frames[i] == ref[j]) {
                flag = 1;
                break;
            }
        }
        if (!flag) {
            return i;
        }
        if (farthest < j) {
            farthest = j;
            replace_index = i;
        }
    }
    return replace_index;
}

// Optimal Page Replacement algorithm
void optimal() {
    int i, j, k;
    for (i = 0; i < m; i++) {
        k = search(ref[i]);
        if (k == -1) {
            k = get_optimal(sp, i);
            frames[k] = ref[i];
            faults++;
            for (j = 0; j < n; j++) {
                mem[j][i] = frames[j];
            }
        }
    }
}

// Main function to accept input, apply the page replacement algorithm, and display results
int main() {
    accept();
    optimal();  // Apply Optimal Page Replacement
    disp();     // Display results
    return 0;
}
