#include <stdio.h>
#include <stdlib.h>

void sort(int arr[], int n) {
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (arr[j] > arr[j + 1]) {
                int temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
}

void c_look(int requestQueue[], int n, int initialhead) {
    int totalH = 0, index, i;
    sort(requestQueue, n);

    for (i = 0; i < n; i++) {
        if (requestQueue[i] >= initialhead) {
            index = i;
            break;
        }
    }
    for (i = index; i < n; i++) {
        totalH += abs(requestQueue[i] - initialhead);
        initialhead = requestQueue[i];
    }

    totalH += abs(requestQueue[0] - initialhead);
    initialhead = requestQueue[0];
    for (i = 0; i < index; i++) {
        totalH += abs(requestQueue[i] - initialhead);
        initialhead = requestQueue[i];
    }
    printf("Total number of head movements: %d\n", totalH);
}

int main() {
    int n, initialhead;
    printf("Enter the number of disk requests: ");
    scanf("%d", &n);    
    int requestQueue[n];
    
    printf("Enter the disk request queue: ");
    for (int i = 0; i < n; i++) {
        scanf("%d", &requestQueue[i]);
    }

    printf("Enter the initial head position: ");
    scanf("%d", &initialhead);

    c_look(requestQueue, n, initialhead);

    return 0;
}
