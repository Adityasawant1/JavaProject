#include <stdio.h>
#include <stdlib.h>

int main() {
    int Rg[100], i, n, th = 0, initial;
    
    printf("Enter no of requests: \n");
    scanf("%d", &n);
    
    printf("Enter the requests sequence: \n");
    for(i = 0; i < n; i++) {
        scanf("%d", &Rg[i]);
    }
    
    printf("Enter initial head position: \n");
    scanf("%d", &initial);
    
    for(i = 0; i < n; i++) {
        th = th + abs(Rg[i] - initial);
        initial = Rg[i];
    }
    
    printf("Total head movement: %d\n", th);  
    return 0;  
}


