#include<stdio.h>
#include<ctype.h>
int main(){
  FILE *fp;
  int mem[1000]={0},opcode,opnd,pc=0,reg[4]={0},reg1,flag;
  
  fp=fopen("demo.txt","r");
  
  if(fp==NULL){
    printf("File not Found");
    return 0;
  }
  while(fscanf(fp,"%d",&mem[pc])!=EOF){
    pc++;
  }
  pc=0;
  mem[115]=1;
  while(1){
    opcode=mem[pc]/10000;
    reg1=(mem[pc]%10000)/1000;
    opnd=mem[pc]%1000;

    switch(opcode){
      case 0:
            printf("Termination");
            return 0;
      case 1:
            reg[reg1]+=mem[opnd];
            break;
      case 2:
            reg[reg1]-=mem[opnd];
            break;
      case 3:
            reg[reg1]*=mem[opnd];
            break;
      case 4:
            reg[reg1]=mem[opnd];
            break;
      case 5:
            mem[opnd]=reg[reg1];
            break;
      case 6:
            if(reg[reg1]<=mem[opnd])
            {flag=0;}
            else
            {flag=1;}
        break;
      case 7:
            if(flag==0)
            {
                pc=2;
            } 
        break;         
      case 8:
            reg[reg1]/=mem[opnd];
      case 9:
            printf("Enter the number:");  
            scanf("%d",&mem[opnd]);
            break;
      case 10:
              printf("Result: %d\n",mem[opnd]);
              break;
      default:
            printf("Invalid opcode:%d\n",opcode);
            break;
      }
      pc++;
    }
    fclose(fp);
    return 0;
}
