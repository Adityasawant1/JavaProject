#include<stdio.h>

struct Process{
  int p,bt,at,st,ft,wt,tat;
};

int main(){
  int n,i,j;
  
  printf("Enter the no of process=");
  scanf("%d",&n);
  struct Process P[n];
  struct Process temp;
    
  for(i=0;i<n;i++){
    P[i].p=i+1;
    printf("Enter the Arrival time of process %d=",P[i].p);
    scanf("%d",&P[i].at); 
    printf("Enter the burst time of process %d=",P[i].p);
    scanf("%d",&P[i].bt);
    
  }
    
  //sort by At
  for(i=0;i<n;i++){
      for(j=i+1;j<n;j++){
          if(P[i].at>P[j].at){
              temp=P[i];
              P[i]=P[j];
              P[j]=temp;
            }
        }
    }

    //sort by BT
    
    P[0].st=P[0].at;
    P[0].ft=P[0].st+P[0].bt;
    P[0].wt=P[0].st-P[0].at;
    P[0].tat=P[0].ft-P[0].at;
  
    for(i=1;i<n;i++){
        P[i].st=P[i-1].ft;
        if(P[i].st<P[i].at)
        {
            P[i].st=P[i].at;
        }
            P[i].ft=P[i].st+P[i].bt;
            P[i].wt=P[i].st-P[i].at;
            P[i].tat=P[i].ft-P[i].at;
      }
      
      //Gantt chart
      printf("Gantt chart\n");
      printf("| P%d",P[0].p);
      for(i=1;i<n;i++){
        printf("| P%d",P[i].p);
      }
      printf(" |\n");
      printf("%d   ",P[0].st);
      for(i=0;i<n;i++){
        printf("%d   ",P[i].ft);
      }
      printf("\n\n");
      
      for(i=0;i<n;i++)
      {
          for(j=i+1;j<n;j++)
          {
              if(P[i].p>P[j].p)
              {
                  temp=P[i];
                  P[i]=P[j];
                  P[j]=temp;
                }
           }
       }


        //Table
        printf("Table:\n");
        printf("Process\tAt\tBt\tSt\tFt\tWt\tTAT\n");
        for(i=0;i<n;i++)
        {
              printf("%d\t%d\t%d\t%d\t%d\t%d\t%d\n",P[i].p, P[i].at, P[i].bt, P[i].st, P[i].ft, P[i].wt, P[i].tat);

        }
      return 0;
}
              
