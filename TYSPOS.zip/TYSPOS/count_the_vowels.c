#include <stdio.h>
#include <ctype.h>
int main(){

  FILE *fp;
  char ch;

  int count=0;

  fp=fopen("demo.txt","r");

  if(fp==NULL)
  {
    printf("file not found");
    return 1;
  }

     while((ch=fgetc(fp))!=EOF)
     {
        ch=tolower(ch);
        if(ch=='a' || ch=='e' || ch=='i' || ch=='o' || ch=='u')
        {
          count++;
        }
      }
    
    
    fclose(fp);
    printf("Count of the vowels=%d\n",count);
    return 0; 
}

