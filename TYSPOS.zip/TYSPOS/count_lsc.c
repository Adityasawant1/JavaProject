#include<stdio.h>
#include<ctype.h>
int main(){
  
    FILE *fp;
    char ch;
    int l=0,s=0,t=0,ch1=0,w=0;
    
    fp=fopen("demo.txt","r");
    if(fp==NULL){
      printf("File not found");
      return 0;
    }
    while((ch=fgetc(fp))!=EOF)
    {
      ch1++;
      if(ch==' '){
        s++,w++;
      }
      if(ch=='\n')
        l++;
      if(ch=='\t')
        t++;
    }
    printf("Character = %d",ch1);
    printf("space and word = %d",s);
    printf("word =%d",w);
    printf("Lines = %d",l);
    printf("Tabs=%d",t);
    
    fclose(fp);
    return 0;
}
